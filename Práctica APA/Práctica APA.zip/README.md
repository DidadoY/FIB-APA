# Autores
* Marc Nebot Moyano
* Alejandro Salvat Navarro

# Instrucciones

Esta práctica se ha realizado en Google Colab, por lo tanto, se recomienda ejecutarla en dicho entorno.

Previamente a la ejecución del notebook, el .csv con los datos ya viene incluido en el .zip entregado, pero, en caso de haber cualquier problema con el archivo, se puede descargar desde el enlace incluido en: enlace_dataset.txt

## Estructura del notebook

El notebook realizado se compone de una primera fase de exploración de datos, previa a una fase de entrenamiento y testeo de los 6 modelos escogidos para la práctica, y acaba con diversas conclusiones extraídas, además de una discusión de cuál opinamos que ha sido el mejor modelo de todos los entrenados.

